export const DB_NAME = 'parrot_consulting';
